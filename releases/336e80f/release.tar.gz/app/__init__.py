"""Inspection accounting Telegram bot."""
